
#include "RegisterFeatures.h"

extern bool gEnableGyroscope;

void RegisterFeatures()
{
    gEnableGyroscope = false;
}

